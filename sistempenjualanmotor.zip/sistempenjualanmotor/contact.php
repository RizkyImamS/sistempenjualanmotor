<!DOCTYPE html>
<html lang="id">

<head>
    <title>MSS | Kontak</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/mss-icon.png">
    <!-- Custom CSS -->
    <link href="assets/extra-libs/c3/c3.min.css" rel="stylesheet">
    <link href="assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <link href="assets/extra-libs/jvector/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
    <!-- Custom CSS -->
    <link href="assets/dist/css/style.min.css" rel="stylesheet">
    <link href="assets/dist/css/sb-admin-2.min.css" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/images/mss.png" alt="logo" width="50">
                Mlaku Speedshop
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="user.php">Beranda</a>
                    </li>
                    <li class="nav-item ml-2">
                        <a class="nav-link" href="about.php">Tentang</a>
                    </li>
                    <li class="nav-item ml-2">
                        <a class="nav-link" href="contact.php">Kontak</a>
                    </li>
<!--                     <li class="nav-item">
                        <a class="nav-link" href="pembelian.php">Shop</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="adminlogin.php">Login</a>
                    </li> -->
                    <li class="nav-item ml-3">
                        <a class="nav-link btn btn-info text-white" href="https://wa.me/6281234567890?text=Halo,%20saya%20ingin%20memesan%20motor" target="_blank">
                            <i class="fab fa-whatsapp"></i> Pesan Sekarang
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="bg-primary text-white text-center py-5">
        <div class="container">
            <h1>Hubungi Kami</h1>
            <p class="lead">Silakan hubungi kami melalui alamat, nomor telepon, atau email di bawah ini.</p>
        </div>
    </header>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card shadow-sm p-4">
                    <h2 class="text-center mb-4">Informasi Kontak</h2>
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <h5>Alamat:</h5>
                            <p>Jl. Raya Bogor No.123, Kota Bogor, Jawa Barat</p>
                        </li>
                        <li class="mb-3">
                            <h5>Nomor Telepon/HP:</h5>
                            <p>Telepon  :  (021) 1234-5678</p>
                            <p>HP       :  +62 81234567890</p>
                        </li>
                        <li>
                            <h5>Email:</h5>
                            <p>info@mlakuspeedshop.com</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-white text-center py-4">
        <div class="container">
            <p class="m-0">&copy; 2024 Mlaku Speedshop. Hak Cipta Dilindungi.</p>
        </div>
    </footer>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
