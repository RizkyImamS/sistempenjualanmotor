# Sistem-Penjualan-Sepeda-Motor
Sistem sederhana untuk mengelola penjualan sepeda motor

# Screenshots
![screencapture-localhost-Database-Final-Task-2023-08-17-20_15_39](https://github.com/IsranLie/Sistem-Penjualan-Sepeda-Motor/assets/95160822/2392408e-997a-4805-8027-96bb1945df6d)
![screencapture-localhost-Database-Final-Task-admin-index-php-2023-08-17-20_16_12](https://github.com/IsranLie/Sistem-Penjualan-Sepeda-Motor/assets/95160822/de3d8af8-8161-413e-9df6-a687a151a631)
