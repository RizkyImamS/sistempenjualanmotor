<!DOCTYPE html>
<html lang="id">

<head>
    <title>MSS | Pembelian Motor</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/mss-icon.png">
    <!-- Custom CSS -->
    <link href="assets/extra-libs/c3/c3.min.css" rel="stylesheet">
    <link href="assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <link href="assets/extra-libs/jvector/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
    <!-- Custom CSS -->
    <link href="assets/dist/css/style.min.css" rel="stylesheet">
    <link href="assets/dist/css/sb-admin-2.min.css" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="assets/images/mss.png" alt="logo" width="50">
                Mlaku Speedshop
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="user.php">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">Tentang</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kontak.php">Kontak</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pembelian.php">Shop</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user_login.php">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="bg-primary text-white text-center py-5">
        <div class="container">
            <h1>Formulir Pembelian Motor</h1>
            <p class="lead">Isi formulir di bawah ini untuk membeli motor impian Anda.</p>
        </div>
    </header>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-sm p-4">
                    <h2 class="text-center mb-4">Informasi Pembelian</h2>
                    <form id="orderForm" onsubmit="generateInvoice(event)">
                        <div class="form-group">
                            <label for="modelMotor">Model Motor</label>
                            <select class="form-control" id="modelMotor" onchange="updatePrice()">
                                <option value="" disabled selected>Pilih Model Motor</option>
                                <option value="Honda Beat">Honda Beat - Rp 16.000.000</option>
                                <option value="Yamaha NMAX">Yamaha NMAX - Rp 30.000.000</option>
                                <option value="Kawasaki Ninja">Kawasaki Ninja - Rp 50.000.000</option>
                                <option value="Suzuki Satria">Suzuki Satria - Rp 24.000.000</option>
                                <option value="Vespa Primavera">Vespa Primavera - Rp 40.000.000</option>
                                <option value="Yamaha Mio">Yamaha Mio - Rp 15.000.000</option>
                                <option value="Honda CBR">Honda CBR - Rp 35.000.000</option>
                                <option value="Yamaha R15">Yamaha R15 - Rp 36.000.000</option>
                                <option value="Honda Vario">Honda Vario - Rp 18.000.000</option>
                                <option value="Suzuki GSX">Suzuki GSX - Rp 28.000.000</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="hargaMotor">Harga Motor</label>
                            <input type="text" class="form-control" id="hargaMotor" readonly>
                        </div>
                        <div class="form-group">
                            <label for="namaLengkap">Nama Lengkap</label>
                            <input type="text" class="form-control" id="namaLengkap" placeholder="Masukkan Nama Lengkap" required>
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <textarea class="form-control" id="alamat" rows="3" placeholder="Masukkan Alamat" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="nomorTelepon">Nomor Telepon/HP</label>
                            <input type="text" class="form-control" id="nomorTelepon" placeholder="Masukkan Nomor Telepon/HP" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" placeholder="Masukkan Email" required>
                        </div>
                        <div class="form-group">
                            <label for="metodePembayaran">Metode Pembayaran</label>
                            <select class="form-control" id="metodePembayaran" required>
                                <option value="" disabled selected>Pilih Metode Pembayaran</option>
                                <option value="Transfer Bank">Transfer Bank</option>
                                <option value="Kartu Kredit">Kartu Kredit</option>
                                <option value="E-Wallet">E-Wallet</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Kirim Pesanan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-white text-center py-4">
        <div class="container">
            <p class="m-0">&copy; 2024 Mlaku Speedshop. Hak Cipta Dilindungi.</p>
        </div>
    </footer>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Script to update price -->
    <script>
        function updatePrice() {
            const modelMotor = document.getElementById('modelMotor');
            const hargaMotor = document.getElementById('hargaMotor');
            const selectedOption = modelMotor.options[modelMotor.selectedIndex].text;
            const price = selectedOption.split(' - ')[1];
            hargaMotor.value = price;
        }

        function generateInvoice(event) {
            event.preventDefault();

            const modelMotor = document.getElementById('modelMotor').value;
            const hargaMotor = document.getElementById('hargaMotor').value;
            const namaLengkap = document.getElementById('namaLengkap').value;
            const alamat = document.getElementById('alamat').value;
            const nomorTelepon = document.getElementById('nomorTelepon').value;
            const email = document.getElementById('email').value;
            const metodePembayaran = document.getElementById('metodePembayaran').value;

            const invoiceWindow = window.open('', 'Invoice', 'width=800,height=600');
            invoiceWindow.document.write(`
                <html>
                <head>
                    <title>Invoice</title>
                    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
                </head>
                <body class="bg-light">
                    <div class="container my-5">
                        <div class="card shadow-sm p-4">
                            <h2 class="text-center mb-4">Invoice Pembelian Motor</h2>
                            <table class="table table-bordered">
                                <tr>
                                    <th>Model Motor</th>
                                    <td>${modelMotor}</td>
                                </tr>
                                <tr>
                                    <th>Harga Motor</th>
                                    <td>${hargaMotor}</td>
                                </tr>
                                <tr>
                                    <th>Nama Lengkap</th>
                                    <td>${namaLengkap}</td>
                                </tr>
                                <tr>
                                    <th>Alamat</th>
                                    <td>${alamat}</td>
                                </tr>
                                <tr>
                                    <th>Nomor Telepon/HP</th>
                                    <td>${nomorTelepon}</td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td>${email}</td>
                                </tr>
                                <tr>
                                    <th>Metode Pembayaran</th>
                                    <td>${metodePembayaran}</td>
                                </tr>
                            </table>
                            <div class="text-center mt-4">
                                <button class="btn btn-primary" onclick="window.print()">Cetak Invoice</button>
                            </div>
                        </div>
                    </div>
                </body>
                </html>
            `);
        }
    </script>
</body>

</html>
