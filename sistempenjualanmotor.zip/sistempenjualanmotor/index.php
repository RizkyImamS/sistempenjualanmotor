<!DOCTYPE html>
<html lang="en">

<head>
    <title>MSS | Landing Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/mss-icon.png">
    <!-- Custom CSS -->
    <link href="assets/extra-libs/c3/c3.min.css" rel="stylesheet">
    <link href="assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <link href="assets/extra-libs/jvector/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
    <!-- Custom CSS -->
    <link href="assets/dist/css/style.min.css" rel="stylesheet">
    <link href="assets/dist/css/sb-admin-2.min.css" rel="stylesheet" type="text/css">
</head>

<body class="bg-light">
    <div class="container d-flex vh-100 justify-content-center align-items-center">
        <div class="text-center">
            <img src="assets/images/mss.png" alt="logo" width="200" class="mb-4">
            <p class="h4 text-dark mb-4">Sistem Penjualan Sepeda Motor <br> MSS</p>
            <a href="adminlogin.php" class="btn btn-info btn-lg mb-2"><strong>Admin</strong></a>
            <a href="user.php" class="btn btn-primary btn-lg mb-2"><strong>User</strong></a>
        </div>
    </div>
</body>

</html>