<?php

// Fungsi ubah
$title = 'Ubah Data Barang';
require 'functions.php';
$db = dbConnect();
$Id = $_GET['id'];
$motor = row_array($db, "SELECT * FROM motor WHERE IdType='$Id'");

$no_rangka = $motor['NoRangka'];
$type = row_array($db, "SELECT * FROM motor
    JOIN type ON `motor`.`IdType` = `type`.`IdType`
    WHERE NoRangka = '$no_rangka'");

if (isset($_POST['btn_simpan'])) {
    if ($db->errno == 0) {
        $IdType = $db->escape_string($_POST['IdType']);
        $rangka = $db->escape_string($_POST['rangka']);
        $varian = $db->escape_string($_POST['varian']);
        $nmrMesin = $db->escape_string($_POST['mesin']);
        $isiSilinder = $db->escape_string($_POST['silinder']);
        $warna = $db->escape_string($_POST['warna']);
        $thnPembuatan = $db->escape_string($_POST['pembuatan']);
        $harga = $db->escape_string($_POST['harga']);
        $stok = $db->escape_string($_POST['stok']);
        $hargabeli = $db->escape_string($_POST['hargabeli']);
        $pengeluaran = $db->escape_string($_POST['pengeluaran']);

        $query = "UPDATE type SET NoMesin='$nmrMesin', IsiSilinder='$isiSilinder', Warna='$warna',TahunPembuatan='$thnPembuatan', Harga='$harga', Harga_beli='$hargabeli', pengeluaran='$pengeluaran' WHERE IdType='$IdType'";
        $execute = execute($db, $query);
        if ($execute == 1) {
            $query2 = "UPDATE motor SET NoRangka='$rangka', NamaVarian='$varian', stok='$stok' WHERE NoRangka='$rangka'";
            $execute2 = execute($db, $query2);
            if ($execute2 == 1) {
                header('location:type.php?msg=4');
            } else {
                header('location:type.php?msg=2');
            }
        } else {
            header('location:type.php?msg=2');
        }
    } else {
        header('location:type.php?msg=' . (DEVELOPMENT ? " : " . $db->connect_error : ""));
    }
}

require 'layout-header.php';
require 'layout-topbar.php';
require 'layout-sidebar.php';
?>
<div class="container-fluid">
    <div class="card">
        <div class="card-body collapse show">
            <h3 class="page-title text-truncate text-primary font-weight-medium mb-1"><?= $title; ?></h3>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-8 col-md-12">
            <div class="card">
                <div class="card-body font-weight">
                    <form action="" method="post" onsubmit="calculateOutcome()">
                        <div class="form-group">
                            <label for="IdType">ID Type</label>
                            <input type="text" name="IdType" class="form-control text-uppercase" value="<?= $type['IdType']; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label for="varian">Nama Varian</label>
                            <input type="text" name="varian" maxlength="20" class="form-control" value="<?= $motor['NamaVarian']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan nama varian')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="rangka">No Rangka</label>
                            <input type="text" name="rangka" class="form-control" maxlength="18" value="<?= $motor['NoRangka']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan no. rangka')" oninput="setCustomValidity('')">
                        </div>

                        <div class="form-group">
                            <label for="mesin">No Mesin</label>
                            <input type="text" name="mesin" class="form-control text-capitalize" maxlength="17" value="<?= $type['NoMesin']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan no. mesin')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="silinder">Isi Silinder</label>
                            <input type="text" name="silinder" class="form-control text-capitalize" maxlength="5" value="<?= $type['IsiSilinder']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan isi silinder')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="warna">Warna</label>
                            <input type="text" name="warna" class="form-control text-capitalize" maxlength="9" value="<?= $type['Warna']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan warna kendaraan')" oninput="setCustomValidity('')">
                        </div>

                        <div class="form-group">
                            <label for="pembuatan">Tahun Pembuatan</label>
                            <input type="number" name="pembuatan" class="form-control text-capitalize" value="<?= $type['TahunPembuatan']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan tahun pembuatan')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="hargabeli">Harga Beli</label>
                            <input type="number" name="hargabeli" id="hargabeli" class="form-control text-capitalize" value="<?= $type['Harga_beli']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan harga beli kendaraan')" oninput="setCustomValidity(''); calculateOutcome();">
                        </div>
                        <div class="form-group">
                            <label for="harga">Harga Jual</label>
                            <input type="number" name="harga" class="form-control text-capitalize" value="<?= $type['Harga']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan harga jual kendaraan')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="stok">Stok</label>
                            <input type="number" name="stok" id="stok" class="form-control text-capitalize" value="<?= $motor['stok']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan stok kendaraan')" oninput="setCustomValidity(''); calculateOutcome();">
                        </div>
                        <div class="form-group">
                            <label for="pengeluaran_display">Pengeluaran</label>
                            <input type="text" id="pengeluaran_display" class="form-control" readonly>
                        </div>

                        <input type="hidden" name="pengeluaran" id="pengeluaran">

                        <a href="javascript:void(0)" onclick="window.history.back();" class="btn btn-rounded btn-dark mt-3">Kembali</a>
                        <button type="submit" class="btn btn-rounded btn-info btn_simpan mt-3" name="btn_simpan">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function calculateOutcome() {
        var price = parseFloat(document.getElementById('hargabeli').value) || 0;
        var quantity = parseInt(document.getElementById('stok').value) || 0;
        var totalOutcome = price * quantity;
        document.getElementById('pengeluaran_display').value = 'Rp ' + totalOutcome.toLocaleString('id-ID');
        document.getElementById('pengeluaran').value = totalOutcome;
    }
    
    window.onload = function() {
        calculateOutcome();
    }
</script>

<?php
require 'layout-footer.php';
?>