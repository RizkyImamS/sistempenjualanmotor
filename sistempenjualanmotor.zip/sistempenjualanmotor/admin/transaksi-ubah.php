<?php
$title = 'Ubah Data Transaksi';
require 'functions.php';
$db = dbConnect();

$tgl = Date('Y-m-d');
$data = get_data($conn, "SELECT `motor`.`NoRangka`, NamaVarian, Warna, Harga, stok FROM motor 
    JOIN type ON `motor`.`IdType` = `type`.`IdType`");

$no_faktur = $db->escape_string($_GET['id']);
$faktur = row_array($conn, "SELECT * FROM faktur WHERE NoFaktur = '$no_faktur'");

$no_ktp = $faktur['NoKTP'];
$pemilik = row_array($conn, "SELECT * FROM pemilik WHERE NoKTP = '$no_ktp'");

$no_rangka = $faktur['NoRangka'];
$type = row_array($conn, "SELECT * FROM motor
    JOIN type ON `motor`.`IdType` = `type`.`IdType`
    WHERE NoRangka = '$no_rangka'");

$stok_awal = $type['stok'];
$jumlah_beli_awal = $faktur['jumlah'];

if (isset($_POST['btn_simpan'])) {
    if ($db->errno == 0) {
        $noFaktur = $db->escape_string($_POST['no_faktur']);
        $tgl = $db->escape_string($_POST['tgl']);
        $petugas = $db->escape_string($_SESSION['id_petugas']);
        $nm_konsumen = $db->escape_string($_POST['nm_konsumen']);
        $noKtp = $db->escape_string($_POST['no_ktp']);
        $alamat = $db->escape_string($_POST['alamat']);
        $noRangka = $db->escape_string($_POST['varian']);
        $jumlah = $db->escape_string($_POST['jumlah']);
        $harga = $db->escape_string($_POST['harga']);
        $total_harga = $db->escape_string($_POST['total_harga']);
        $keterangan = $db->escape_string($_POST['keterangan']);

        // Hitung perubahan stok
        $selisih_jumlah = $jumlah - $jumlah_beli_awal;
        $stok_baru = $stok_awal - $selisih_jumlah;

        if ($stok_baru < 0) {
            header('location:transaksi.php?msg=stok tidak mencukupi');
            exit;
        }

        $query = "UPDATE pemilik SET NoKTP='$noKtp', NamaPemilik='$nm_konsumen', AlamatPemilik='$alamat', keterangan='$keterangan' WHERE NoKTP='$no_ktp'";
        $execute = execute($conn, $query);
        if ($execute == 1) {
            $query2 = "UPDATE faktur SET NoFaktur='$noFaktur', Tgl='$tgl', NoKTP='$noKtp', NoRangka='$noRangka', IdPetugas='$petugas', total_harga='$total_harga', jumlah='$jumlah' WHERE NoFaktur='$no_faktur'";
            $execute2 = execute($conn, $query2);
            if ($execute2 == 1) {
                // Update stok motor
                $query3 = "UPDATE motor SET stok='$stok_baru' WHERE NoRangka='$noRangka'";
                $execute3 = execute($conn, $query3);
                if ($execute3 == 1) {
                    header('location:transaksi.php?msg=4');
                } else {
                    header('location:transaksi.php?msg=Gagal mengupdate stok motor');
                }
            } else {
                header('location:transaksi.php?msg=2');
            }
        } else {
            header('location:transaksi.php?msg=2');
        }
    } else {
        header('location:transaksi.php?msg=' . (DEVELOPMENT ? " : " . $db->connect_error : ""));
    }
}

require 'layout-header.php';
require 'layout-topbar.php';
require 'layout-sidebar.php';
?>
<div class="container-fluid">
    <div class="card">
        <div class="card-body collapse show">
            <h3 class="page-title text-truncate text-primary font-weight-medium mb-1"><?= $title; ?></h3>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-7 col-md-12">
            <div class="card">
                <div class="card-body font-weight">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="">Nomor Faktur</label>
                            <input type="text" name="no_faktur" class="form-control" value="<?= $faktur['NoFaktur']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="">Tanggal</label>
                            <input type="date" name="tgl" class="form-control" value="<?= $tgl; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="">Nama Konsumen</label>
                            <input type="text" name="nm_konsumen" class="form-control" maxlength="20" value="<?= $pemilik['NamaPemilik']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan Nama Konsumen')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="">No. KTP</label>
                            <input type="number" name="no_ktp" class="form-control" min="1" value="<?= $pemilik['NoKTP']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan No. KTP Konsumen')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="">Alamat</label>
                            <input type="text" name="alamat" class="form-control" maxlength="30" value="<?= $pemilik['AlamatPemilik']; ?>" required oninvalid="this.setCustomValidity('Silahkan masukkan Alamat Konsumen')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="">Varian Sepeda Motor</label>
                            <select name="varian" id="varian" class="form-control" required onchange="updatePrice()" oninvalid="this.setCustomValidity('Silahkan pilih Varian Sepeda Motor')" oninput="setCustomValidity('')">
                                <option value="<?= $type['NoRangka']; ?>" data-price="<?= $type['Harga']; ?>" data-stock="<?= $type['stok']; ?>"><?= $type['NamaVarian']; ?> - <?= $type['Warna']; ?></option>
                                <?php foreach ($data as $varian) : ?>
                                    <option value="<?= $varian['NoRangka']; ?>" data-price="<?= $varian['Harga']; ?>" data-stock="<?= $varian['stok']; ?>"><?= $varian['NamaVarian']; ?> - <?= $varian['Warna']; ?> (stok: <?= $varian['stok']; ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Jumlah Beli</label>
                            <input type="number" name="jumlah" id="jumlah" class="form-control" maxlength="30" value="<?= $faktur['jumlah']; ?>" placeholder="Masukkan Jumlah Beli" required onchange="calculateTotalPrice()" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="">Total Harga</label>
                            <input type="text" id="total_harga_display" class="form-control" value="Rp <?= number_format($faktur['total_harga'], 0, ',', '.'); ?>" required oninvalid="this.setCustomValidity('')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="keterangan">Keterangan</label>
                            <select class="form-control" id="keterangan" name="keterangan" value="<?= $faktur['Keterangan']; ?>" required oninvalid="this.setCustomValidity('')" oninput="setCustomValidity('')">
                                <option value="" disabled selected>Pilih Keterangan</option>
                                <option value="Belum Lunas">Belum Lunas</option>
                                <option value="Sudah Lunas">Sudah Lunas</option>  
                            </select>
                        </div>


                        <input type="hidden" name="harga" id="harga" value="<?= $type['Harga']; ?>">
                        <input type="hidden" name="total_harga" id="total_harga" value="<?= $faktur['total_harga']; ?>">

                        <a href="javascript:void(0)" onclick="window.history.back();" class="btn btn-rounded btn-dark mt-3">Kembali</a>
                        <button type="submit" class="btn btn-rounded btn-info mt-3" name="btn_simpan">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function updatePrice() {
        var selectedVariant = document.querySelector('#varian option:checked');
        var price = selectedVariant.getAttribute('data-price');
        document.getElementById('harga').value = price;
        calculateTotalPrice();
    }

    function calculateTotalPrice() {
        var price = parseFloat(document.getElementById('harga').value) || 0;
        var quantity = parseInt(document.getElementById('jumlah').value) || 0;
        var totalPrice = price * quantity;
        document.getElementById('total_harga_display').value = 'Rp ' + totalPrice.toLocaleString('id-ID');
        document.getElementById('total_harga').value = totalPrice;
    }

    window.onload = function() {
        updatePrice();
    }
</script>

<?php
require 'layout-footer.php';
?>