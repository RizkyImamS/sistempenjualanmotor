<?php
session_start();
define("DEVELOPMENT", TRUE);
require '../assets/libs/fpdf184/fpdf.php';

if ($_SESSION) {
} else {
    header('location:../index.php?msg=6');
}

function dbConnect()
{
    $db = new mysqli("localhost", "root", "", "penjualan_motor");
    return $db;
}

$conn = dbConnect();

function get_data($conn, $query)
{
    $data = mysqli_query($conn, $query);
    if (mysqli_num_rows($data) > 0) {
        while ($row = mysqli_fetch_assoc($data)) {
            $hasil[] = $row;
        }
        return $hasil;
    }
}

function row_array($conn, $query)
{
    $db = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($db);
}

function execute($conn, $query)
{
    $db = mysqli_query($conn, $query);

    if ($db) {
        return 1;
    } else {
        return 0;
    }
}

function reduce_stock($conn, $no_rangka, $quantity) {
    $query = "SELECT Stok FROM motor WHERE NoRangka = '$no_rangka'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $data = mysqli_fetch_assoc($result);
        $current_stock = $data['Stok'];

        if ($current_stock >= $quantity) {
            $new_stock = $current_stock - $quantity;
            $update_query = "UPDATE motor SET Stok = '$new_stock' WHERE NoRangka = '$no_rangka'";
            $update_result = mysqli_query($conn, $update_query);

            return $update_result ? true : false;
        } else {
            return false; // Stok tidak mencukupi
        }
    } else {
        return false; // Gagal mengambil stok
    }
}


?>