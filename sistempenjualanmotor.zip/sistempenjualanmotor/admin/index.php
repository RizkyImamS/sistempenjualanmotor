<?php
$title = 'Dashboard';
require 'layout-header.php';
require 'layout-topbar.php';
require 'layout-sidebar.php';

// Cek koneksi database
if (!isset($conn)) {
    $conn = dbConnect();
}
?>

<div class="container-fluid">
    <!-- Page title card -->
    <div class="card my-4">
        <div class="card-body collapse show bg-primary text-white">
            <h3 class="page-title text-truncate font-weight-medium mb-1"><?= $title; ?></h3>
        </div>
    </div>

    <!-- Card group for stats -->
    <div class="row">
        <!-- Transaksi card -->
        <div class="col-md-3 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Transaksi</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php
                                $query = "SELECT COUNT(NoFaktur) AS total_transaksi FROM faktur";
                                $result = row_array($conn, $query);
                                ?>
                                <?= $result['total_transaksi']; ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-donate fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Barang card -->
        <div class="col-md-3 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Barang</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php
                                $query = "SELECT COUNT(NoRangka) AS total_barang FROM motor";
                                $result = row_array($conn, $query);
                                ?>
                                <?= $result['total_barang']; ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-box fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Petugas card -->
        <div class="col-md-3 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Petugas</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php
                                $query = "SELECT COUNT(IdPetugas) AS total_petugas FROM petugas";
                                $result = row_array($conn, $query);
                                ?>
                                <?= $result['total_petugas']; ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-user fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pemasukan card -->
        <div class="col-md-3 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pemasukan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <sup class="set-doller">Rp</sup>
                                <?php
                                $query = "SELECT SUM(total_harga) AS total_pemasukan FROM faktur";
                                $result = row_array($conn, $query);
                                ?>
                                <?= number_format($result['total_pemasukan']); ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-book fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pengeluaran card -->
        <div class="col-md-3 mb-4">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Pengeluaran</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <sup class="set-doller">Rp</sup>
                                <?php
                                $query = "SELECT SUM(pengeluaran) AS total_pengeluaran FROM type";
                                $result = row_array($conn, $query);
                                ?>
                                <?= number_format($result['total_pengeluaran']); ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-file fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require 'layout-footer.php';
?>
