<?php
require 'functions.php';

$db = dbConnect();

$no_faktur = $db->escape_string($_GET['id']);
$data = row_array($conn, "SELECT * FROM faktur
            JOIN pemilik ON `faktur`.`NoKTP` = `pemilik`.`NoKTP`
            JOIN motor ON `faktur`.`NoRangka` = `motor`.`NoRangka`
            JOIN type ON `type`.`IdType` = `motor`.`IdType`
            JOIN petugas ON `faktur`.`IdPetugas` = `petugas`.`IdPetugas`
            WHERE NoFaktur = '$no_faktur'");

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();

// Judul Invoice
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(190, 10, 'INVOICE PEMBELIAN MOTOR', 0, 1, 'C');
$pdf->Cell(190, 10, 'MLAKU SPEEDSHOP', 0, 1, 'C');


// Garis pemisah
$pdf->SetLineWidth(0.5);
$pdf->Line(10, 35, 200, 35);
$pdf->Ln(10);

// Informasi Faktur
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(40, 10, 'No. Faktur', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['NoFaktur'], 0, 1);

$pdf->Cell(40, 10, 'Tanggal', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['Tgl'], 0, 1);

$pdf->Cell(40, 10, 'Petugas', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['NamaPetugas'], 0, 1);

$pdf->Ln(10);

// Informasi Pemilik
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(40, 10, 'No. KTP', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['NoKTP'], 0, 1);

$pdf->SetFont('Arial', '', 12);
$pdf->Cell(40, 10, 'Pemilik', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['NamaPemilik'], 0, 1);

$pdf->Cell(40, 10, 'Alamat', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['AlamatPemilik'], 0, 1);

$pdf->Ln(10);

// Informasi Sepeda Motor
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(40, 10, 'ID Type', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['IdType'], 0, 1);

$pdf->SetFont('Arial', '', 12);
$pdf->Cell(40, 10, 'Sepeda Motor', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['NamaVarian'], 0, 1);

$pdf->Cell(40, 10, 'No. Rangka', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['NoRangka'], 0, 1);

$pdf->Cell(40, 10, 'No. Mesin', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['NoMesin'], 0, 1);

$pdf->Cell(40, 10, 'Isi Silinder', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['IsiSilinder'], 0, 1);

$pdf->Cell(40, 10, 'Tahun Pembuatan', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['TahunPembuatan'], 0, 1);

$pdf->Cell(40, 10, 'Warna', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['Warna'], 0, 1);

$pdf->Cell(40, 10, 'Harga', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, 'Rp. ' . number_format($data['Harga'], 0, ',', '.'), 0, 1);

$pdf->Cell(40, 10, 'Jumlah Beli', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, $data['jumlah'], 0, 1);

$pdf->Cell(40, 10, 'Total Harga', 0, 0);
$pdf->Cell(5, 10, ':', 0, 0);
$pdf->Cell(145, 10, 'Rp. ' . number_format($data['total_harga'], 0, ',', '.'), 0, 1);

$pdf->Ln(10);

// Tanda Tangan
$pdf->Cell(150, 10, '', 0, 0);
$pdf->Cell(40, 10, '     Tanda Tangan', 0, 1);

$pdf->Ln(20);

// Nama Petugas
$pdf->Cell(150, 10, '', 0, 0);
$pdf->Cell(40, 10, $data['NamaPetugas'], 0, 1);

$pdf->Output('nota-transaksi-' . $data['NoFaktur'] . '.pdf', 'I');
?>