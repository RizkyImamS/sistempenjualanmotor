<?php
$title = 'Tambah Transaksi';
require 'functions.php';
$db = dbConnect();
$no_faktur = 'FK/ABI/' . date('mdi') . '/R';
$tgl = date('Y-m-d');
$data = get_data($conn, "SELECT `motor`.`NoRangka`, NamaVarian, Warna, Harga, Stok FROM motor 
    JOIN type ON `motor`.`IdType` = `type`.`IdType`");

if (isset($_POST['btn_simpan'])) {
    if ($db->errno == 0) {
        $no_faktur = $db->escape_string($_POST['no_faktur']);
        $tgl = $db->escape_string($_POST['tgl']);
        $petugas = $db->escape_string($_SESSION['id_petugas']);
        $nm_konsumen = $db->escape_string($_POST['nm_konsumen']);
        $no_ktp = $db->escape_string($_POST['no_ktp']);
        $alamat = $db->escape_string($_POST['alamat']);
        $no_rangka = $db->escape_string($_POST['varian']);
        $jumlah = $db->escape_string($_POST['jumlah']);
        $harga = $db->escape_string($_POST['harga']);
        $total_harga = $db->escape_string($_POST['total_harga']);
        $mtd_pembayaran = $db->escape_string($_POST['mtd_pembayaran']);
        $keterangan = $db->escape_string($_POST['keterangan']);

        $query = row_array($conn, "SELECT * FROM faktur WHERE NoFaktur = '$no_faktur'");
        if (!$query) {
            $query = "INSERT INTO pemilik (NoKTP, NamaPemilik, AlamatPemilik, MetodePembayaran, Keterangan) 
            VALUES ('$no_ktp', '$nm_konsumen', '$alamat', '$mtd_pembayaran', '$keterangan')";
            $execute = execute($conn, $query);
            if ($execute == 1) {
                $query2 = "INSERT INTO faktur (NoFaktur, Tgl, NoKTP, NoRangka, IdPetugas, jumlah, total_harga) 
                VALUES ('$no_faktur', '$tgl', '$no_ktp', '$no_rangka', '$petugas', '$jumlah', '$total_harga')";
                $execute2 = execute($conn, $query2);
                if ($execute2 == 1) {
                    if (reduce_stock($conn, $no_rangka, $jumlah)) {
                        header('location:transaksi.php?msg=3');
                    } else {
                        header('location:transaksi.php?msg=Stock not reduced');
                    }
                } else {
                    header('location:transaksi.php?msg=Failed to insert into faktur');
                }
            } else {
                header('location:transaksi.php?msg=Failed to insert into pemilik');
            }
        } else {
            header('location:transaksi.php?msg=Faktur already exists');
        }
    } else {
        header('location:transaksi.php?msg=DB connection error');
    }
}

require 'layout-header.php';
require 'layout-topbar.php';
require 'layout-sidebar.php';
?>
<div class="container-fluid">
    <div class="card">
        <div class="card-body collapse show">
            <h3 class="page-title text-truncate text-primary font-weight-medium mb-1"><?= $title; ?></h3>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-7 col-md-12">
            <div class="card">
                <div class="card-body font-weight">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="">Nomor Faktur</label>
                            <input type="text" name="no_faktur" class="form-control" value="<?= $no_faktur; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="">Tanggal</label>
                            <input type="date" name="tgl" class="form-control" value="<?= $tgl; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="">Nama Konsumen</label>
                            <input type="text" name="nm_konsumen" class="form-control" maxlength="20" placeholder="Masukkan nama konsumen" required oninvalid="this.setCustomValidity('Silahkan masukkan Nama Konsumen')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="">No. KTP</label>
                            <input type="number" name="no_ktp" class="form-control" min="1" maxlength="20" placeholder="Masukkan No. KTP Konsumen" required oninvalid="this.setCustomValidity('Silahkan masukkan No. KTP Konsumen')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="">Alamat</label>
                            <input type="text" name="alamat" class="form-control" maxlength="30" placeholder="Masukkan alamat konsumen" required oninvalid="this.setCustomValidity('Silahkan masukkan Alamat Konsumen')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="">Varian Sepeda Motor</label>
                            <select name="varian" id="varian" class="form-control" required onchange="updatePrice()" oninvalid="this.setCustomValidity('Silahkan pilih Varian Sepeda Motor')" oninput="setCustomValidity('')">
                                <option value="">Pilih varian sepeda motor</option>
                                <?php foreach ($data as $varian) : ?>
                                    <option value="<?= $varian['NoRangka']; ?>" data-price="<?= $varian['Harga']; ?>" data-stock="<?= $varian['Stok']; ?>"><?= $varian['NamaVarian']; ?> - <?= $varian['Warna']; ?> (Stok: <?= $varian['Stok']; ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Jumlah Beli</label>
                            <input type="number" name="jumlah" id="jumlah" class="form-control" maxlength="30" placeholder="Masukkan Jumlah Beli" required onchange="calculateTotalPrice()" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="">Total Harga</label>
                            <input type="text" id="total_harga_display" class="form-control" required oninvalid="this.setCustomValidity('')" oninput="setCustomValidity('')">
                        </div>
                        <div class="form-group">
                            <label for="mtd_pembayaran">Metode Pembayaran</label>
                            <select class="form-control" id="mtd_pembayaran" name="mtd_pembayaran" required oninvalid="this.setCustomValidity('')" oninput="setCustomValidity('')">
                                <option value="" disabled selected>Pilih Metode Pembayaran</option>
                                <option value="Transfer Bank">Transfer Bank</option>
                                <option value="Kartu Kredit">Kartu Kredit</option>  
                                <option value="E-Wallet">E-Wallet</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="keterangan">Keterangan</label>
                            <select class="form-control" id="keterangan" name="keterangan" required oninvalid="this.setCustomValidity('')" oninput="setCustomValidity('')">
                                <option value="" disabled selected>Pilih Keterangan</option>
                                <option value="Belum Lunas">Belum Lunas</option>
                                <option value="Sudah Lunas">Sudah Lunas</option>  
                            </select>
                        </div>

                        <input type="hidden" name="harga" id="harga">
                        <input type="hidden" name="total_harga" id="total_harga">
                        <input type="hidden" name="stock" id="stock">

                        <a href="javascript:void(0)" onclick="window.history.back();" class="btn btn-rounded btn-dark mt-3">Kembali</a>
                        <button type="submit" class="btn btn-rounded btn-info mt-3" name="btn_simpan">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function updatePrice() {
    var selectedVariant = document.querySelector('#varian option:checked');
    var price = selectedVariant.getAttribute('data-price');
    var stock = selectedVariant.getAttribute('data-stock');
    document.getElementById('harga').value = price;
    document.getElementById('stock').value = stock;
    calculateTotalPrice();
}

function calculateTotalPrice() {
    var price = parseFloat(document.getElementById('harga').value) || 0;
    var quantity = parseInt(document.getElementById('jumlah').value) || 0;
    var stock = parseInt(document.getElementById('stock').value) || 0;

    if (quantity > stock) {
        alert('Jumlah beli melebihi stok yang tersedia!');
        document.getElementById('jumlah').value = stock; // Set jumlah maksimum sesuai dengan stok yang tersedia
        quantity = stock; // Set nilai quantity ke stok yang tersedia
    }

    var totalPrice = price * quantity;
    document.getElementById('total_harga_display').value = 'Rp ' + totalPrice.toLocaleString('id-ID');
    document.getElementById('total_harga').value = totalPrice;
}

window.onload = function() {
    updatePrice();
}
</script>

<?php
require 'layout-footer.php';
?>
