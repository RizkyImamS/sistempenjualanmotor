<?php
$title = 'Laporan';
require 'functions.php';
require 'layout-header.php';
require 'layout-topbar.php';
require 'layout-sidebar.php';

$data = get_data($conn, "SELECT * FROM faktur
    JOIN pemilik ON `faktur`.`NoKTP` = `pemilik`.`NoKTP`
    JOIN motor ON `faktur`.`NoRangka` = `motor`.`NoRangka`
    JOIN type ON `motor`.`IdType` = `type`.`IdType`");
    ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-body bg-primary text-white">
                <h3 class="page-title text-truncate font-weight-medium"><?= $title; ?></h3>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>No. Faktur</th>
                                        <th>Tanggal</th>
                                        <th>Konsumen</th>
                                        <th>Jumlah Beli</th>
                                        <th>Total Harga</th>
                                        <th>Metode Pembayaran</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;
                                    foreach ($data as $faktur) : ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= $faktur['NoFaktur']; ?></td>
                                            <td><?= $faktur['Tgl']; ?></td>
                                            <td><?= $faktur['NamaPemilik']; ?></td>
                                            <td><?= $faktur['jumlah']; ?></td>
                                            <td>Rp <?= number_format($faktur['total_harga'], 0, ',', '.'); ?></td>
                                            <td><?= $faktur['MetodePembayaran']; ?></td>
                                            <td><?= $faktur['Keterangan']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    require 'layout-footer.php';
    ?>
